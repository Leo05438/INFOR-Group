/**
 * All languages that comes with release.
 */
package prettify.lang;