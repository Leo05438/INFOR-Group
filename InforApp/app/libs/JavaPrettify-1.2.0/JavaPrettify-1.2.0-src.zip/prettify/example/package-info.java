/**
 * Usage example.
 */
package prettify.example;